import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weeks',
  templateUrl: './weeks.component.html',
  styleUrls: ['./weeks.component.scss']
})
export class WeeksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
