import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'planner';
}


// const firebaseConfig = {
//   apiKey: "AIzaSyBorl8xTDZsaRyXKAQyDhcsit5C5J457pE",
//   authDomain: "planner-71a2e.firebaseapp.com",
//   databaseURL: "https://planner-71a2e-default-rtdb.europe-west1.firebasedatabase.app",
//   projectId: "planner-71a2e",
//   storageBucket: "planner-71a2e.appspot.com",
//   messagingSenderId: "404343797920",
//   appId: "1:404343797920:web:c76d074993aeffb6d331c5",
//   measurementId: "G-LQVRYZBGJB"
// };
